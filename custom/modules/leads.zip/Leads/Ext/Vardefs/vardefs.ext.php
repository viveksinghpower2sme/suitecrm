<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2016-01-11 12:50:54
$dictionary['Lead']['fields']['cst_c']['inline_edit']='1';
$dictionary['Lead']['fields']['cst_c']['labelValue']='CST';

 

// created: 2016-03-31 15:32:10
$dictionary["Lead"]["fields"]["abc12_data_leads_1"] = array (
  'name' => 'abc12_data_leads_1',
  'type' => 'link',
  'relationship' => 'abc12_data_leads_1',
  'source' => 'non-db',
  'module' => 'abc12_Data',
  'bean_name' => 'abc12_Data',
  'vname' => 'LBL_ABC12_DATA_LEADS_1_FROM_ABC12_DATA_TITLE',
  'id_name' => 'abc12_data_leads_1abc12_data_ida',
);
$dictionary["Lead"]["fields"]["abc12_data_leads_1_name"] = array (
  'name' => 'abc12_data_leads_1_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ABC12_DATA_LEADS_1_FROM_ABC12_DATA_TITLE',
  'save' => true,
  'id_name' => 'abc12_data_leads_1abc12_data_ida',
  'link' => 'abc12_data_leads_1',
  'table' => 'abc12_data',
  'module' => 'abc12_Data',
  'rname' => 'name',
);
$dictionary["Lead"]["fields"]["abc12_data_leads_1abc12_data_ida"] = array (
  'name' => 'abc12_data_leads_1abc12_data_ida',
  'type' => 'link',
  'relationship' => 'abc12_data_leads_1',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_ABC12_DATA_LEADS_1_FROM_ABC12_DATA_TITLE',
);



$dictionary['Lead']['fields']['e_invite_status_fields'] =
		array (
			'name' => 'e_invite_status_fields',
			'rname' => 'id',
			'relationship_fields'=>array('id' => 'event_invite_id', 'invite_status' => 'event_status_name'),
			'vname' => 'LBL_CONT_INVITE_STATUS',
			'type' => 'relate',
			'link' => 'fp_events_leads_1',
			'link_type' => 'relationship_info',
            'join_link_name' => 'fp_events_leads_1',
			'source' => 'non-db',
			'importable' => 'false',
            'duplicate_merge'=> 'disabled',
			'studio' => false,
		);


$dictionary['Lead']['fields']['event_status_name'] =
		array(
            'massupdate' => false,
            'name' => 'event_status_name',
            'type' => 'enum',
            'studio' => 'false',
            'source' => 'non-db',
            'vname' => 'LBL_LIST_INVITE_STATUS_EVENT',
            'options' => 'fp_event_invite_status_dom',
            'importable' => 'false',
        );
$dictionary['Lead']['fields']['event_invite_id'] =
    array(
        'name' => 'event_invite_id',
        'type' => 'varchar',
        'source' => 'non-db',
        'vname' => 'LBL_LIST_INVITE_STATUS',
        'studio' => array('listview' => false),
    );


$dictionary['Lead']['fields']['e_accept_status_fields'] =
        array (
            'name' => 'e_accept_status_fields',
            'rname' => 'id',
            'relationship_fields'=>array('id' => 'event_status_id', 'accept_status' => 'event_accept_status'),
            'vname' => 'LBL_CONT_ACCEPT_STATUS',
            'type' => 'relate',
            'link' => 'fp_events_leads_1',
            'link_type' => 'relationship_info',
            'join_link_name' => 'fp_events_leads_1',
            'source' => 'non-db',
            'importable' => 'false',
            'duplicate_merge'=> 'disabled',
            'studio' => false,
        );


$dictionary['Lead']['fields']['event_accept_status'] =
        array(
            'massupdate' => false,
            'name' => 'event_accept_status',
            'type' => 'enum',
            'studio' => 'false',
            'source' => 'non-db',
            'vname' => 'LBL_LIST_ACCEPT_STATUS_EVENT',
            'options' => 'fp_event_status_dom',
            'importable' => 'false',
        );
$dictionary['Lead']['fields']['event_status_id'] =
    array(
        'name' => 'event_status_id',
        'type' => 'varchar',
        'source' => 'non-db',
        'vname' => 'LBL_LIST_ACCEPT_STATUS',
        'studio' => array('listview' => false),
    );

 // created: 2016-04-27 12:39:29
$dictionary['Lead']['fields']['rank_c']['inline_edit']='1';
$dictionary['Lead']['fields']['rank_c']['labelValue']='Rank';

 

 // created: 2016-01-11 12:54:37
$dictionary['Lead']['fields']['epf_c']['inline_edit']='1';
$dictionary['Lead']['fields']['epf_c']['labelValue']='EPF';

 

// created: 2016-03-30 10:59:30
$dictionary["Lead"]["fields"]["abc12_data_leads_2"] = array (
  'name' => 'abc12_data_leads_2',
  'type' => 'link',
  'relationship' => 'abc12_data_leads_2',
  'source' => 'non-db',
  'module' => 'abc12_Data',
  'bean_name' => 'abc12_Data',
  'vname' => 'LBL_ABC12_DATA_LEADS_2_FROM_ABC12_DATA_TITLE',
  'id_name' => 'abc12_data_leads_2abc12_data_ida',
);
$dictionary["Lead"]["fields"]["abc12_data_leads_2_name"] = array (
  'name' => 'abc12_data_leads_2_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ABC12_DATA_LEADS_2_FROM_ABC12_DATA_TITLE',
  'save' => true,
  'id_name' => 'abc12_data_leads_2abc12_data_ida',
  'link' => 'abc12_data_leads_2',
  'table' => 'abc12_data',
  'module' => 'abc12_Data',
  'rname' => 'name',
);
$dictionary["Lead"]["fields"]["abc12_data_leads_2abc12_data_ida"] = array (
  'name' => 'abc12_data_leads_2abc12_data_ida',
  'type' => 'link',
  'relationship' => 'abc12_data_leads_2',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_ABC12_DATA_LEADS_2_FROM_ABC12_DATA_TITLE',
);


 // created: 2016-01-11 12:32:42
$dictionary['Lead']['fields']['pan_c']['inline_edit']='1';
$dictionary['Lead']['fields']['pan_c']['labelValue']='Pan';

 

 // created: 2016-01-11 12:25:56
$dictionary['Lead']['fields']['companyname_c']['inline_edit']='1';
$dictionary['Lead']['fields']['companyname_c']['labelValue']='Company Name';

 


$dictionary['Lead']['fields']['SecurityGroups'] = array (
  	'name' => 'SecurityGroups',
    'type' => 'link',
	'relationship' => 'securitygroups_leads',
	'module'=>'SecurityGroups',
	'bean_name'=>'SecurityGroup',
    'source'=>'non-db',
	'vname'=>'LBL_SECURITYGROUPS',
);






 // created: 2016-01-11 12:52:45
$dictionary['Lead']['fields']['excise_c']['inline_edit']='1';
$dictionary['Lead']['fields']['excise_c']['labelValue']='EXCISE';

 

 // created: 2015-12-22 13:30:30
$dictionary['Lead']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 

 // created: 2016-01-11 12:51:20
$dictionary['Lead']['fields']['tan_c']['inline_edit']='1';
$dictionary['Lead']['fields']['tan_c']['labelValue']='TAN';

 

 // created: 2016-01-11 12:55:04
$dictionary['Lead']['fields']['registration_c']['inline_edit']='1';
$dictionary['Lead']['fields']['registration_c']['labelValue']='REGISTRATION';

 

 // created: 2016-01-11 12:53:45
$dictionary['Lead']['fields']['ssi_c']['inline_edit']='1';
$dictionary['Lead']['fields']['ssi_c']['labelValue']='SSI';

 

 // created: 2016-01-11 12:05:05
$dictionary['Lead']['fields']['businesstype_c']['inline_edit']='1';
$dictionary['Lead']['fields']['businesstype_c']['labelValue']='Business Type';

 

 // created: 2016-01-11 12:59:58
$dictionary['Lead']['fields']['turn_over_c']['inline_edit']='1';
$dictionary['Lead']['fields']['turn_over_c']['labelValue']='TURN OVER';

 

// created: 2013-04-30 14:52:24
$dictionary["Lead"]["fields"]["fp_events_leads_1"] = array (
  'name' => 'fp_events_leads_1',
  'type' => 'link',
  'relationship' => 'fp_events_leads_1',
  'source' => 'non-db',
  'vname' => 'LBL_FP_EVENTS_LEADS_1_FROM_FP_EVENTS_TITLE',
);


 // created: 2016-04-13 12:53:29
$dictionary['Lead']['fields']['region_c']['inline_edit']='1';
$dictionary['Lead']['fields']['region_c']['labelValue']='Region ';

 

 // created: 2016-01-11 12:30:21
$dictionary['Lead']['fields']['grade_c']['inline_edit']='1';
$dictionary['Lead']['fields']['grade_c']['labelValue']='Grade';

 

// created: 2016-04-05 18:06:32
$dictionary["Lead"]["fields"]["phone_phone_leads_1"] = array (
  'name' => 'phone_phone_leads_1',
  'type' => 'link',
  'relationship' => 'phone_phone_leads_1',
  'source' => 'non-db',
  'module' => 'phone_Phone',
  'bean_name' => 'phone_Phone',
  'vname' => 'LBL_PHONE_PHONE_LEADS_1_FROM_PHONE_PHONE_TITLE',
);


 // created: 2016-01-11 12:29:15
$dictionary['Lead']['fields']['designation_c']['inline_edit']='1';
$dictionary['Lead']['fields']['designation_c']['labelValue']='Designation';

 

 // created: 2015-12-22 13:30:30
$dictionary['Lead']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 

 // created: 2016-05-03 16:13:32
$dictionary['Lead']['fields']['type_c']['inline_edit']='1';
$dictionary['Lead']['fields']['type_c']['labelValue']='Type';

 

 // created: 2016-05-10 17:01:29
$dictionary['Lead']['fields']['test_c']['inline_edit']='1';
$dictionary['Lead']['fields']['test_c']['labelValue']='Test';

 

 // created: 2016-04-19 18:14:13
$dictionary['Lead']['fields']['create_contact_c']['inline_edit']='1';
$dictionary['Lead']['fields']['create_contact_c']['labelValue']='Create Contact';

 

 // created: 2016-01-11 12:50:26
$dictionary['Lead']['fields']['vat_c']['inline_edit']='1';
$dictionary['Lead']['fields']['vat_c']['labelValue']='VAT';

 

// created: 2016-05-18 16:37:22
$dictionary["Lead"]["fields"]["fp_event_locations_leads_1"] = array (
  'name' => 'fp_event_locations_leads_1',
  'type' => 'link',
  'relationship' => 'fp_event_locations_leads_1',
  'source' => 'non-db',
  'module' => 'FP_Event_Locations',
  'bean_name' => 'FP_Event_Locations',
  'vname' => 'LBL_FP_EVENT_LOCATIONS_LEADS_1_FROM_FP_EVENT_LOCATIONS_TITLE',
);


 // created: 2016-01-11 12:56:36
$dictionary['Lead']['fields']['year_of_incorporation_c']['inline_edit']='1';
$dictionary['Lead']['fields']['year_of_incorporation_c']['labelValue']='Year Of Incorporation';

 

// created: 2016-03-16 17:12:25
$dictionary["Lead"]["fields"]["abc12_data_leads_3"] = array (
  'name' => 'abc12_data_leads_3',
  'type' => 'link',
  'relationship' => 'abc12_data_leads_3',
  'source' => 'non-db',
  'module' => 'abc12_Data',
  'bean_name' => 'abc12_Data',
  'vname' => 'LBL_ABC12_DATA_LEADS_3_FROM_ABC12_DATA_TITLE',
  'id_name' => 'abc12_data_leads_3abc12_data_ida',
);
$dictionary["Lead"]["fields"]["abc12_data_leads_3_name"] = array (
  'name' => 'abc12_data_leads_3_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ABC12_DATA_LEADS_3_FROM_ABC12_DATA_TITLE',
  'save' => true,
  'id_name' => 'abc12_data_leads_3abc12_data_ida',
  'link' => 'abc12_data_leads_3',
  'table' => 'abc12_data',
  'module' => 'abc12_Data',
  'rname' => 'name',
);
$dictionary["Lead"]["fields"]["abc12_data_leads_3abc12_data_ida"] = array (
  'name' => 'abc12_data_leads_3abc12_data_ida',
  'type' => 'link',
  'relationship' => 'abc12_data_leads_3',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_ABC12_DATA_LEADS_3_FROM_ABC12_DATA_TITLE',
);


// created: 2016-01-07 16:35:43
$dictionary["Lead"]["fields"]["phone_phone_leads"] = array (
  'name' => 'phone_phone_leads',
  'type' => 'link',
  'relationship' => 'phone_phone_leads',
  'source' => 'non-db',
  'module' => 'phone_Phone',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_PHONE_PHONE_LEADS_FROM_PHONE_PHONE_TITLE',
);


 // created: 2016-04-29 13:06:26
$dictionary['Lead']['fields']['vertical_c']['inline_edit']='1';
$dictionary['Lead']['fields']['vertical_c']['labelValue']='Vertical';

 

 // created: 2016-01-11 12:51:54
$dictionary['Lead']['fields']['servicetax_c']['inline_edit']='1';
$dictionary['Lead']['fields']['servicetax_c']['labelValue']='SERVICE TAX';

 

 // created: 2015-12-22 13:30:31
$dictionary['Lead']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 

 // created: 2015-12-22 13:30:31
$dictionary['Lead']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 
?>